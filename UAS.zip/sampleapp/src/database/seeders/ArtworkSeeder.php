<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Artwork;

class ArtworkSeeder extends Seeder
{
    public function run(): void
    {
        Artwork::create([
            'title' => 'Sample Artwork',
            'description' => 'This is a sample artwork description.',
            'file_path' => 'uploads/sample.jpg',
            'user_id' => 1,  // Pastikan user dengan ID 1 ada di database
            'category_id' => 1,  // Pastikan category dengan ID 1 ada di database
        ]);
    }
}
